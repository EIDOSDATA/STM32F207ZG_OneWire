.. _um:

User manual
===========

.. toctree::
    :maxdepth: 2

    how-it-works
    thread-safety
    hw-connection
    uart-timing
    porting-guide